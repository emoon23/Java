import java.util.function.BooleanSupplier;

public class MyUnit {
	
	public String concatenate(String one, String two) {
		return one + two;
		
	}


}
