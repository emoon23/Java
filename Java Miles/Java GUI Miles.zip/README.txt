Project title: Mile Redeemer GUI program

The purpose for this program was to create a GUI airline ticket app. The user is allowed to select a city and below the event frame will display 
normal miles, supersaver miles, upgrade cost, and supersaver dates. On the redeem miles side the user can
enter in a random mile, select the month of departure and click on the button "redeem miles". The event frame will display a trip to a city name in a certain class
for example: "A trip to Sydney in economy class". Below the event frame will display the remaining miles.

To test out this program, recommend using dr.java here is link: http://www.drjava.org/download.shtml (download windows app via http)
I tried running this in eclipise neon (java ide) but it was causing errors. I was able to get this program to run properly through dr.java