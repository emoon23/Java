Project title: FutureValueApp
(Java)

The purpose of this program is to create a calculator application that calculates,formates, and displays the results for each
calculation. The user asked to enter a monthly investment, a yearly interest rate, and number of years. After inputting in the values
the program will print the results and will ask the user if he/she wants to continue.

This program was created through netbeans ide(java). In order to test this program please install netbeans. 
Here is the link: https://netbeans.org/downloads/8.0.2/ make sure the correct JDK is also installed. 
In order to view the source code of this program. Download the zip folder and extract the files.
After unzipping, the folder should be named FutureValueApp and the source code will be in the src folder.
A screenshot is also provided to show an example output.